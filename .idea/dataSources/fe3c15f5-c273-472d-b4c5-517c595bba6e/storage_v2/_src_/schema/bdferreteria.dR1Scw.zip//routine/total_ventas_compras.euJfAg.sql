create procedure total_ventas_compras(IN ano_mes varchar(100))
  begin
    select sum(DM.Cantidad_Producto * DM.Precio_Unitario) as Total from movimientos as M
          inner join detalle_movimientos as DM
                on M.Codigo_Movimiento=DM.Codigo_Movimiento
          inner join productos as P
                on P.Codigo_Producto=DM.Codigo_Producto where M.Fecha like concat(ano_mes,'%') #año y mes
    group by M.Tipo_Movimiento;
  end;

